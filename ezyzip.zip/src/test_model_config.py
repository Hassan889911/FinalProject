from src.model_config import ModelConfig

def test_model_config():
    config_data = {
        "type": "logistic_regression",
        "parameters": {
            "learning_rate": 0.01,
            "epochs": 100
        }
    }
    model_config = ModelConfig(**config_data)
    assert model_config.type == "logistic_regression"
    assert model_config.parameters.learning_rate == 0.01
    assert model_config.parameters.epochs == 100
