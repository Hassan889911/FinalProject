import mlflow
import mlflow.sklearn

def setup_mlflow():
    """
    Set up MLflow tracking URI and any necessary configurations.
    """
    # Example: Set the tracking URI (default is the local directory)
    mlflow.set_tracking_uri("http://127.0.0.1:5000")  # You can change the URI if you are using a different server
    
    # Optionally, you can set the experiment name
    mlflow.set_experiment("Titanic_Experiment")

def log_metrics_and_model(model, X_test, y_test, model_name: str, params: dict):
    """
    Log model parameters, metrics, and the model itself to MLflow.
    """
    with mlflow.start_run():
        # Log parameters
        for param_name, param_value in params.items():
            mlflow.log_param(param_name, param_value)

        # Log metrics
        accuracy = model.score(X_test, y_test)
        mlflow.log_metric("accuracy", accuracy)

        # Log the model
        mlflow.sklearn.log_model(model, model_name)
        print(f"Model logged with accuracy: {accuracy}")
