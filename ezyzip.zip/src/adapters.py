class OldModel:
    def old_train(self, data):
        print("Old model training")

class NewModelAdapter:
    def __init__(self, old_model):
        self.old_model = old_model

    def train(self, data):
        self.old_model.old_train(data)
