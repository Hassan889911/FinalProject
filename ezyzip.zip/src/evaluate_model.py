import mlflow
import mlflow.sklearn
from logging_setup import get_logger

logger = get_logger()

def evaluate_model(run_id, data):
    """
    Evaluate the trained Titanic model and log results.
    """
    logger.info("Starting model evaluation.")
    X_test, y_test = data["X_test"], data["y_test"]
    
    try:
        # Load the trained model
        model_uri = f"runs:/{run_id}/TitanicModel"
        model = mlflow.sklearn.load_model(model_uri)
        
        # Evaluate accuracy on the test set
        accuracy = model.score(X_test, y_test)
        mlflow.log_metric("evaluation_accuracy", accuracy)
        
        logger.info(f"Evaluation completed. Test Accuracy: {accuracy}")
    except Exception as e:
        logger.error(f"Error during model evaluation: {e}")
        raise
