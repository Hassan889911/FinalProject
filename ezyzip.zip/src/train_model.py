import mlflow
import mlflow.sklearn
import yaml
from sklearn.ensemble import RandomForestClassifier
from data_preprocessing import preprocess_data

def load_config(config_path="config.yaml"):
    """Load the configuration file."""
    with open(config_path, "r") as file:
        config = yaml.safe_load(file)
    return config

def train_model(X_train, y_train, X_test, y_test, params):
    """
    Train the model using the provided data and log it with MLflow.
    """
    with mlflow.start_run() as run:
        # Log model parameters
        for param, value in params.items():
            mlflow.log_param(param, value)

        # Train the model
        model = RandomForestClassifier(
            n_estimators=params['n_estimators'], 
            max_depth=params['max_depth'], 
            random_state=params['random_state']
        )
        model.fit(X_train, y_train)
        
        # Log the trained model
        mlflow.sklearn.log_model(model, "TitanicModel")
        
        # Log metrics
        train_accuracy = model.score(X_train, y_train)
        test_accuracy = model.score(X_test, y_test)
        mlflow.log_metric("train_accuracy", train_accuracy)
        mlflow.log_metric("test_accuracy", test_accuracy)

        print(f"Model trained and logged with run ID: {run.info.run_id}")
        print(f"Train Accuracy: {train_accuracy}, Test Accuracy: {test_accuracy}")

    return model
