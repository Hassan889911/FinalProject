import os
import subprocess
import time
import pandas as pd
import mlflow
import socket
from config_loader import load_config
from train_model import train_model
from data_preprocessing import preprocess_data, load_data
from train import train_and_evaluate
from prometheus_client import start_http_server, Summary

# Create a metric to track model inference times
inference_duration = Summary('inference_duration_seconds', 'Time spent performing inference')

@inference_duration.time()
def predict(model, X):
    return model.predict(X)

# Start the Prometheus server on a different port
start_http_server(8000)
def is_mlflow_running(host='localhost', port=5000, timeout=5):
    """
    Check if MLflow server is running on the specified host and port.
    """
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (socket.timeout, socket.error):
        print("MLflow server not reachable.")
        return False

def start_mlflow_server():
    """
    Start the MLflow server.
    """
    print("Starting MLflow server...")
    subprocess.Popen(
        ["mlflow", "ui", "--host", "0.0.0.0", "--port", "5000"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    time.sleep(5)  # Give the server time to start

def setup_mlflow_experiment(experiment_name):
    """
    Set up MLflow experiment for tracking. If the experiment already exists, it will be used; otherwise, a new one will be created.
    """
    try:
        mlflow.set_experiment(experiment_name)
        print(f"Experiment '{experiment_name}' is set up for tracking.")
    except mlflow.exceptions.MlflowException:
        new_experiment_name = f"{experiment_name}_new"
        mlflow.set_experiment(new_experiment_name)
        print(f"Experiment '{new_experiment_name}' is set up for tracking instead.")

def main():
    """
    Main function to load data, preprocess it, train the model, and evaluate it.
    """
    # Set MLflow tracking URI programmatically
    mlflow.set_tracking_uri('http://localhost:5000')

    # Load configuration
    config = load_config()

    # Check if MLflow server is running
    if not is_mlflow_running():
        start_mlflow_server()
        if not is_mlflow_running():
            raise ConnectionError("Failed to start MLflow server on localhost:5000.")

    # Set up MLflow experiment
    setup_mlflow_experiment(config["mlflow"]["experiment_name"])

    # Load Titanic dataset
    data = load_data("data/train.csv")  # Ensure your Titanic dataset path is correct

    # Preprocess data
    X_train, X_test, y_train, y_test = preprocess_data(data)

    # Train and evaluate the model
    train_and_evaluate(X_train, y_train, X_test, y_test)

if __name__ == "__main__":
    main()
