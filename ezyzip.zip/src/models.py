from typing import Dict, Any, Optional
from pydantic import BaseModel

class ExampleModel(BaseModel):
    __pydantic_extra__: Optional[Dict[str, Any]]
    __pydantic_private__: Optional[Dict[str, Any]]



class Model:
    def train(self, data):
        pass
    
    def evaluate(self, data):
        pass


class LogisticRegressionModel(Model):
    def train(self, data):
        print("Training Logistic Regression Model")

    def evaluate(self, data):
        print("Evaluating Logistic Regression Model")


class RandomForestModel(Model):
    def train(self, data):
        print("Training Random Forest Model")

    def evaluate(self, data):
        print("Evaluating Random Forest Model")

