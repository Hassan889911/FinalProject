import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split

def load_data(file_path):
    """
    Load the Titanic dataset from the provided CSV file.
    """
    return pd.read_csv(file_path)

def preprocess_data(data):
    """
    Preprocess the Titanic dataset:
    - Handle missing values
    - Encode categorical features
    - Split the data into train and test sets
    """
    # Handle missing values
    data['Age'] = data['Age'].fillna(data['Age'].median())
    data['Embarked'] = data['Embarked'].fillna(data['Embarked'].mode()[0])
    data['Fare'] = data['Fare'].fillna(data['Fare'].median())

    # Define feature columns
    categorical_cols = ['Sex', 'Embarked', 'Pclass']
    numerical_cols = ['Age', 'Fare', 'SibSp', 'Parch']

    # Prepare the column transformer
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", "passthrough", numerical_cols),
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), categorical_cols)
        ]
    )

    # Preprocess the data
    X = preprocessor.fit_transform(data)

    # Extract target variable
    y = data['Survived']

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Return train/test splits for both features and target
    return X_train, X_test, y_train, y_test
