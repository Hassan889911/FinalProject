from .models import LogisticRegressionModel, RandomForestModel

class ModelFactory:
    @staticmethod
    def create_model(model_type):
        if model_type == "logistic_regression":
            return LogisticRegressionModel()
        elif model_type == "random_forest":
            return RandomForestModel()
        else:
            raise ValueError(f"Unsupported model type '{model_type}'. Supported types are: logistic_regression, random_forest.")
