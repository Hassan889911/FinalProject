from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from mlflow_handler import log_metrics_and_model
from train_model import train_model
from titanic_model import create_random_forest_model

def train_model(X_train, y_train, X_test, y_test, params):
    """
    Train the model and log it to MLflow.
    """
    model_type = params.get("model_type", "logistic_regression")

    if model_type == "logistic_regression":
        model = LogisticRegression(max_iter=params.get("max_iter", 100), C=params.get("C", 1.0))
    elif model_type == "random_forest":
        model = RandomForestClassifier(
            n_estimators=params.get("n_estimators", 100),
            max_depth=params.get("max_depth", None),
            random_state=params.get("random_state", 42)
        )
    else:
        raise ValueError(f"Unsupported model type: {model_type}")

    # Train the model
    model.fit(X_train, y_train)

    # Log metrics and model to MLflow
    log_metrics_and_model(model, X_test, y_test, model_type, params)

def train_and_evaluate(X_train, y_train, X_test, y_test):
    """
    Train the model, evaluate it, and log results.
    """
    # Define model parameters
    params = {
        'n_estimators': 100,
        'max_depth': 5,
        'random_state': 42
    }

    # Call the train_model function (no need to pass model as argument)
    trained_model = train_model(X_train, y_train, X_test, y_test, params)
    
    # Now you can evaluate the trained model or do other things with it
    # For example, you can make predictions or log metrics
    return trained_model
