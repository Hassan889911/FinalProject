import mlflow

def promote_model_to_production(run_id, model_name):
    """
    Transition a model version to the 'Production' stage in the MLflow Model Registry.
    """
    # Register model with MLflow Model Registry
    model_uri = f"runs:/{run_id}/random_forest_model"
    mlflow.register_model(model_uri, model_name)
    
    # Get the registered model version
    client = mlflow.tracking.MlflowClient()
    model_version = client.get_latest_versions(model_name, stages=["None"])[0].version
    
    # Transition the model to "Production"
    client.transition_model_version_stage(
        name=model_name,
        version=model_version,
        stage="Production"
    )
    print(f"Model '{model_name}' version {model_version} transitioned to 'Production'.")
