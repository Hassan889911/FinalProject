class TrainingStrategy:
    def train(self, model, data):
        pass

class SimpleTrainingStrategy(TrainingStrategy):
    def train(self, model, data):
        print("Training with Simple Strategy")

class AdvancedTrainingStrategy(TrainingStrategy):
    def train(self, model, data):
        print("Training with Advanced Strategy")
