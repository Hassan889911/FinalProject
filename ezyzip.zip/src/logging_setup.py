from loguru import logger

# Setup logger
logger.add("logs/app.log", rotation="500 MB", retention="10 days", level="INFO")

def get_logger():
    return logger
