import mlflow
import mlflow.sklearn
from logging_setup import get_logger
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

logger = get_logger()

def train_model(data):
    """
    Train the Titanic model, log metrics, and return the run ID.
    """
    logger.info("Training model started.")
    X_train, y_train = data["X_train"], data["y_train"]
    X_test, y_test = data["X_test"], data["y_test"]
    
    model = LogisticRegression(max_iter=500)
    
    with mlflow.start_run() as run:
        # Log parameters
        mlflow.log_param("model_type", "LogisticRegression")
        
        # Train and log the model
        model.fit(X_train, y_train)
        mlflow.sklearn.log_model(model, "TitanicModel")
        
        # Log metrics
        train_accuracy = model.score(X_train, y_train)
        test_accuracy = model.score(X_test, y_test)
        mlflow.log_metric("train_accuracy", train_accuracy)
        mlflow.log_metric("test_accuracy", test_accuracy)
        
        logger.info(f"Model training completed. Train Accuracy: {train_accuracy}, Test Accuracy: {test_accuracy}")
        
        return run.info.run_id

def evaluate_model(run_id, data):
    """
    Evaluate the Titanic model on test data and log evaluation metrics.
    """
    logger.info("Evaluating model started.")
    X_test, y_test = data["X_test"], data["y_test"]
    
    with mlflow.start_run(run_id=run_id):
        # Load the model from the run
        model_uri = f"runs:/{run_id}/TitanicModel"
        model = mlflow.sklearn.load_model(model_uri)
        
        # Evaluate the model
        test_accuracy = model.score(X_test, y_test)
        mlflow.log_metric("evaluation_accuracy", test_accuracy)
        
        logger.info(f"Model evaluation completed. Test Accuracy: {test_accuracy}")
def create_random_forest_model(params):
    """
    Create a RandomForest model with the provided parameters.
    """
    model = RandomForestClassifier(**params)
    return model
