from omegaconf import OmegaConf
from typing import Any

def load_config(config_file: str = "config/config.yaml") -> Any:
    """
    Load the configuration from a YAML file.
    
    Args:
        config_file (str): The path to the YAML configuration file (default is "config/config.yaml").
        
    Returns:
        Any: The loaded configuration, typically as an OmegaConf object.
    """
    # Load the YAML configuration file using OmegaConf
    config = OmegaConf.load(config_file)
    return config
