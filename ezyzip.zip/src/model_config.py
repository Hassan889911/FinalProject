from pydantic import BaseModel
from typing import Dict
from typing import Any


class Parameters(BaseModel):
    learning_rate: float
    epochs: int

class ModelConfig(BaseModel):
    type: str
    parameters: Parameters  # Nested model for parameters

def validate_model_config(config_data: Dict[str, Any]) -> ModelConfig:
    """
    Validates and parses the model configuration data into a ModelConfig instance.
    
    Args:
        config_data (Dict[str, Any]): The raw configuration data as a dictionary.
        
    Returns:
        ModelConfig: The validated and parsed ModelConfig instance.
        
    Raises:
        ValueError: If the configuration data is invalid.
    """
    return ModelConfig(**config_data)
