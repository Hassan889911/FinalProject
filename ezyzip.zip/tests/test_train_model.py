import pytest
import pandas as pd
from src.train_model import train_model
from sklearn.preprocessing import LabelEncoder

# Sample data for testing
@pytest.fixture
def sample_data():
    # Creating a small sample dataset similar to Titanic dataset
    data = {
        'Pclass': [3, 1, 3, 1],
        'Name': ['A', 'B', 'C', 'D'],
        'Age': [22, 38, 26, 35],
        'SibSp': [1, 1, 0, 1],
        'Parch': [0, 0, 0, 0],
        'Fare': [7.25, 71.2833, 7.925, 53.1],
        'Survived': [0, 1, 1, 0]
    }
    return pd.DataFrame(data)

# Test function for training the model
def test_train_model(sample_data):
    # Preprocessing categorical columns: using LabelEncoder for 'Pclass' and 'Name'
    encoder = LabelEncoder()
    sample_data['Pclass'] = encoder.fit_transform(sample_data['Pclass'])
    sample_data['Name'] = encoder.fit_transform(sample_data['Name'])

    model_params = {"max_depth": 5}
    
    # Call the train_model function
    model, X_test, y_test, y_pred = train_model(sample_data, model_params)

    # Assertions to verify the output (modify this as per your model's actual output)
    assert model is not None, "Model should be trained"
    assert len(X_test) > 0, "X_test should contain test data"
    assert len(y_test) > 0, "y_test should contain the true labels"
    assert len(y_pred) > 0, "y_pred should contain predicted labels"
