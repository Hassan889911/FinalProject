from src.evaluate_model import evaluate_model

def test_evaluate_model():
    y_test = [0, 1, 1, 0]
    y_pred = [0, 1, 0, 0]

    accuracy, conf_matrix = evaluate_model(y_test, y_pred)

    assert accuracy == 0.75  # The accuracy should be 0.75
    assert conf_matrix[0, 0] == 2  # Check number of true negatives (updated to 2)
    assert conf_matrix[0, 1] == 0  # Check number of false positives
    assert conf_matrix[1, 0] == 1  # Check number of false negatives
    assert conf_matrix[1, 1] == 1  # Check number of true positives
