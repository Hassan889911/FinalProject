from invoke import task

@task
def lint(c):
    """
    Run linting using ruff to ensure code quality.
    """
    c.run("ruff check .")

@task
def type_check(c):
    """
    Run type checking using mypy to ensure type correctness.
    """
    c.run("mypy src")

@task
def test(c):
    """
    Run unit tests using pytest.
    """
    c.run("PYTHONPATH=src pytest tests")

@task
def format(c):
    """
    Format code using black or similar tools (if configured).
    """
    c.run("black src tests")

@task
def all_checks(c):
    """
    Run all checks: linting, type checking, and testing.
    """
    lint(c)
    type_check(c)
    test(c)
