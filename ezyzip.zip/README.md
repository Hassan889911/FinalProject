# Titanic Project

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your_username/titanic_project.git
   ```

2. Install dependencies using Poetry:
   ```bash
   poetry install
   ```

## Usage

- **Train the Model**:
  ```bash
  poetry run train
  ```

- **Run Inference**:
  ```bash
  poetry run inference
  ```

## Docker

To run the application using Docker, you can use the following commands:

1. Build the Docker image:
   ```bash
   docker-compose build
   ```

2. Run the services:
   ```bash
   docker-compose up
   ```

## Contributing

- Fork the repository and create a new branch.
- Make your changes and submit a pull request.
